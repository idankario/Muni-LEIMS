from PIL import Image
import sys
from botocore.config import Config
import boto3, botocore, os, re, base64
from io import BytesIO
import base64
import requests
Image.MAX_IMAGE_PIXELS = None

BucketName = os.environ['BUCKET_NAME']
s3 = boto3.client('s3', region_name=os.environ['AWSREGION'],)

def spltImage(im_frame,typeImg,fileName):
    imgwidth, imgheight = im_frame.size
    count=0
    for h in range(round(imgheight/416)):
        for w in range(round(imgheight/416)):
            try:
                width = (w+1)*416
                if(width > imgwidth):
                    width = imgwidth
                height = (h+1)*416
                if(height > imgheight):
                    height = imgheight
                buffer = BytesIO()   
                box = (w*416, h*416, width, height)
                cropImg=im_frame.crop(box)
                cropImg.convert('RGB').save(buffer, 'JPEG')
                img_str = base64.b64encode(buffer.getvalue())
                img_str = img_str.decode("ascii")
                # Construct the URL
                upload_url = "".join([
                    "https://detect.roboflow.com/muni-leims-3ocqe/1",
                    "?api_key=eQ7XBuiO7kvtNCMUIz0j",
                    "&name="+fileName
                ])
                # POST to the API
                r = requests.post(upload_url, data=img_str, headers={
                    "Content-Type": "application/x-www-form-urlencoded"
                })
                count=count+len(r.json()['predictions'])
                # Output result
                print(count)
            except Exception as e:
                print(e)
    print("sss00099")
    return count
    
            
            
            
            # buffer.seek(0)
            # Upload image to s3
            # s3.upload_fileobj(
            #     buffer, 
            #     BucketName,
            #     fileName+"/"+str(h+1)+'*'+str(w+1)+'.jpg',
            # )
     





