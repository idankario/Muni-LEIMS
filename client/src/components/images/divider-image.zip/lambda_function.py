import urllib.parse
import boto3
from PIL import Image
from io import BytesIO
from spliter import spltImage


import os
import time
regionName     = os.environ['AWSREGION']
def lambda_handler(event, context):
    start = time.time()
    s3 = boto3.client('s3',region_name=regionName)
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(
        event['Records'][0]['s3']['object']['key'], encoding='utf-8')
 
    try:
        # Fetch the file from S3
        fileObj = s3.get_object(Bucket=bucket, Key=key)
        file_content = fileObj["Body"].read()
        count=spltImage(Image.open(BytesIO(file_content)),key.split(".")[-1],key.split(".")[0])

        end = time.time()
        print(end - start)
    except Exception as e:
        print(e)
       
