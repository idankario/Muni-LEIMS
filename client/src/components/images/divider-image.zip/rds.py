# import pymysql
# import os
# # rds settings
# rds_host = os.environ['RDS_HOST']
# name = os.environ['RDS_USERNAME']
# password = os.environ['RDS_PASSWORD']

# def analystic(count,fileName):
#     global conn
#     try:
#         print("Opening Connection")
#         if(conn is None):
#             conn = pymysql.connect(
#                 rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
#         elif (not conn.open):
#             # print(conn.open)
#             conn = pymysql.connect(
#                 rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
#         print(count)
        
#     except Exception as e:
#         print (e)
#         print("ERROR: Unexpected error: Could not connect to MySql instance.")